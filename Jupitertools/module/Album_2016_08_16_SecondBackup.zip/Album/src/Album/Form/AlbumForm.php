<?php
namespace Album\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Doctrine\ORM\Query\AST\Functions\CurrentDateFunction;
use Zend\Db\Sql\Ddl\Column\Date;
class AlbumForm extends Form
{

    public function __construct($name = null)
    {
        parent::__construct('album');
        $this->add(array(
            'name'=>'id',
            'type'=>'text',
            'options'=>array('label' =>'ID')));
        $this->add(array(
            'name'=>'ip',
            'type'=>'text',
            'options'=>array('label' =>'IP Address')));
//         $this->add(array(
//             'name'=>'added',
//             'type'=>'date',
//             'attributes'=>array(
//                 'value' =>'2000-08-17 00:00:00'),
//             'options'=>array('label' =>'Added')));        
        $this->add(array(
            'name'=>'add_ip',
            'type'=>'submit',
            'attributes'=>array(
                'value' =>'Add New IP',
                'id'=>'submitbutton'
            )));
        $added = new Element\Text('added');
       $date=date("Y-m-d H:m:s");  
        $added->setLabel('Added')
        ->setAttributes(array(
//             'class' => 'username',
            'value'  => $date,
        ));
        $this->add($added);
      
    }
}

