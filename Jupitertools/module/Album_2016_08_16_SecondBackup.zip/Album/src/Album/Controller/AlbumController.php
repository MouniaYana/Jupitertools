<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Album for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Album\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Album\Model\Album;          // <-- Add this import
use Album\Form\AlbumForm;       // <-- Add this import

use Zend\View\Model\JsonModel;



class AlbumController extends AbstractActionController
{protected $albumTable;
    public function indexAction()
    {     $form = new AlbumForm();
        $form->get('ip')->setValue('Add');
        $request = $this->getRequest();
        if ($request->isPost()) {
            $album = new Album();
            $form->setInputFilter($album->getInputFilter());
            $form->setData($request->getPost());
        
            if ($form->isValid()) {
                $album->exchangeArray($form->getData());
                $this->getAlbumTable()->saveAlbum($album);
        
                // Redirect to list of albums
                
                return $this->redirect()->toRoute('album');
            }
        }
         return array(
             'albums' => $this->getAlbumTable()->fetchAll(),
             'form' => $form,
             
         );
    }

    public function addAction()
    {
        
//         $form = new AlbumForm();
//          $form->get('ip')->setValue('Add');

//          $request = $this->getRequest();
//          if ($request->isPost()) {
//              $album = new Album();
//              $form->setInputFilter($album->getInputFilter());
//              $form->setData($request->getPost());

//              if ($form->isValid()) {
//                  $album->exchangeArray($form->getData());
//                  $this->getAlbumTable()->saveAlbum($album);

//                  // Redirect to list of albums
//                  return $this->redirect()->toRoute('album');
//              }
//          }
//          return array('form' => $form);
//        

    }
    public function getAlbumTable()
    {
        if (!$this->albumTable) {
            $sm = $this->getServiceLocator();
            $this->albumTable = $sm->get('Album\Model\AlbumTable');
        }
        return $this->albumTable;
    }
    
    public function editAction(){
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('album', array(
                'action' => 'edit'
            ));
        }
        
        // Get the Album with the specified id.  An exception is thrown
        // if it cannot be found, in which case go to the index page.
        try {
            $album = $this->getAlbumTable()->getAlbum($id);
        }
        catch (\Exception $ex) {
            return $this->redirect()->toRoute('album', array(
                'action' => 'index'
            ));
        }
        
        $form  = new AlbumForm();
        $form->bind($album);
        $form->get('add_ip')->setAttribute('value', 'Edit');
        
        $request = $this->getRequest();
        if ($request->isPost()) {
            $form->setInputFilter($album->getInputFilter());
            $form->setData($request->getPost());
        
            if ($form->isValid()) {
                $this->getAlbumTable()->saveAlbum($album);
        
                // Redirect to list of albums
                return $this->redirect()->toRoute('album');
            }
        }
        
        return array(
            'id' => $id,
            'form' => $form,
        );
        }
        public function deleteAction()
        {
//             $id = (int) $this->params()->fromRoute('id', 0);
//             if (!$id) {
//                 return $this->redirect()->toRoute('album');
//             }
        
//             $request = $this->getRequest();
//             if ($request->isPost()) {
//                 $del = $request->getPost('del', 'No');
        
//                 if ($del == 'Yes') {
//                     $id = (int) $request->getPost('id');
//                     $this->getAlbumTable()->deleteAlbum($id);
//                 }
        
//                 // Redirect to list of albums
//                 return $this->redirect()->toRoute('album');
//             }
        
//             return array(
//                 'id'    => $id,
//                 'album' => $this->getAlbumTable()->getAlbum($id)
//             );
$id=(int)$_POST['id'];
$this->getAlbumTable()->deleteAlbum($id);
$msg="the selected IP was successfuly deleted";
$response=new JsonModel(array('response'=>$msg));
return $response;
        }
    
}
